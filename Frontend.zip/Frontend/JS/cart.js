// cart.js

$(document).ready(function () {
  const user = JSON.parse(sessionStorage.getItem("loggedInUser"));

  if (!user) {
    alert("Please login to view your cart.");
    window.location.href = "login.html";
    return;
  }

  const userId = user.UserID;
  const apiUrl = `http://localhost:60565/api/cart/user/${userId}`;

  function loadCart() {
    $.ajax({
      url: apiUrl,
      method: "GET",
      success: function (cartItems) {
        const container = $("#cart-items-container");
        container.empty();

        if (cartItems.length === 0) {
          $(".empty-cart-message").removeClass("hidden");
          $("#cart-total").hide();
          return;
        }

        $(".empty-cart-message").addClass("hidden");
        $("#cart-total").show();

        let totalAmount = 0;

        cartItems.forEach(item => {
          totalAmount += item.TotalPrice;

          const card = `
            <div class="cart-card">
              <img src="${item.PerfumeImg}" alt="${item.PerfumeName}">
              <div class="cart-card-details">
                <h3>${item.PerfumeName}</h3>
                <p>Price: ₹${item.PerfumePrice}</p>
                <p>Quantity: ${item.CartQty}</p>
                <p>Total: ₹${item.TotalPrice}</p>
                <button class="remove-btn" data-id="${item.CartID}">Remove</button>
              </div>
            </div>
          `;

          container.append(card);
        });

        $("#cart-total-amount").text(`Total: ₹${totalAmount}`);
      },
      error: function () {
        alert("Error loading cart. Try again later.");
      }
    });
  }

  // Remove item from cart
  $(document).on("click", ".remove-btn", function () {
    const cartId = $(this).data("id");

    $.ajax({
      url: `http://localhost:60565/api/cart/delete/${cartId}`,
      method: "DELETE",
      success: function () {
        loadCart(); // Reload cart after delete
      },
      error: function () {
        alert("Failed to remove item.");
      }
    });
  });

  // Checkout (clear user cart)
  $("#checkout-btn").click(function () {
    $.ajax({
      url: `http://localhost:60565/api/cart/clear/user/${userId}`,
      method: "DELETE",
      success: function () {
        alert("Checkout successful. Thank you for shopping!");
        loadCart(); // Refresh cart after clearing
      },
      error: function () {
        alert("Failed to checkout. Try again.");
      }
    });
  });

  loadCart();
});
