
// export const baseurl="http://localhost:60565/api/user"

// export const routto={
//     getuser:"get-all"
//     getbyid:"get"
// }